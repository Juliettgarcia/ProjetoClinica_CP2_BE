package br.com.juliettgarcia.projetoClinicaCP2.domain.entity.api.handler;

public record Problema(Integer status,
                       String message,
                       String detail) {
}
