package br.com.juliettgarcia.projetoClinicaCP2.domain.entity;

public enum EspecialdiadeEnum {
    ORTODONTISTA, ODONTOPEDIATRA, CLINICO_GERAL, IMPLANTODENTISTA
}
