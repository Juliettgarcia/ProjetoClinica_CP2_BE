package br.com.juliettgarcia.projetoClinicaCP2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoClinicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoClinicaApplication.class, args);
	}

}
